package com.example.masjit_vendor_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
